var urlhead="https://voice.lenovomm.com";
//var urlhead="";