/**
 * Created by liuyang on 2017/8/21.
 */
function app_menu_to_list() {
    window.location.href = "../application/applist.html";
}

function app_menu_to_new() {
    window.location.href = "../application/appnew.html";
}

function app_menu_to_update() {
    window.location.href = "../application/appupdate.html";
}

function app_menu_to_deleted() {
    window.location.href = "../application/appdeleted.html";
}

function app_menu_to_detail() {
    window.location.href = "../application/appdetail.html";
}















