/**
 * Created by liuyang on 2017/8/23.
 */

function forum_menum_to_new(){
    window.location.href = "../forum/questionnew.html";
}

function forum_menum_to_list(){
    window.location.href = "../forum/questionlist.html";
}

function forum_menum_to_detail(){
    window.location.href = "../forum/questiondetail.html";
}
function forum_to_homepage(){
    window.location.href = "../forum/homepage.html"
}



