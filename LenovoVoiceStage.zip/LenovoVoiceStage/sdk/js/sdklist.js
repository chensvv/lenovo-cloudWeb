/**
 * Created by liuyang on 2017/9/9.
 */
$(function () {
    loadTop("sdk");
});