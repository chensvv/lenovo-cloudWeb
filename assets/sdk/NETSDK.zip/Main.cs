﻿using System.Collections;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using SimpleHTTP;
using UnityEngine.UI;
using UnityEngine.Networking;
using System;
using System.Text;



public class Main : MonoBehaviour {

	private Text errorText;
	private Text successText;
    private string URL = "https://voice.lenovomm.com/lasf/asr";

	void Start () {
		errorText = GameObject.Find ("ErrorText").GetComponent<Text> ();
		successText = GameObject.Find ("SuccessText").GetComponent<Text> ();
	}

    IEnumerator PostWithFormData() {
        // This file recoding asks a simple question "What is your name?"
        byte[] soundbyte = File.ReadAllBytes("RECORDING.M4A");
        byte[] newSoundbyte = new byte[soundbyte.Length + 4];
        newSoundbyte[0] = 5;  
        newSoundbyte[1] = 0;
        newSoundbyte[2] = 0;
        newSoundbyte[3] = 0;
        soundbyte.CopyTo(newSoundbyte, 4);

        if (soundbyte == null) 
        {
            Debug.Log("ERROR! File is empty.");
        };
        
        StringBuilder builder = new StringBuilder();

        builder.Append("cpf").Append("=").Append("android");
        builder.Append("&dtp").Append("=").Append("lenovo");
        builder.Append("&ver").Append("=").Append("1.1.9");
        builder.Append("&did").Append("=").Append("90:a4:de:ba:41:a5");
        builder.Append("&uid").Append("=").Append(526);//改为随机数
        builder.Append("&dev").Append("=").Append("com.lenovo.rt.urc");
        builder.Append("&app").Append("=").Append("com.lenovo.leos.lestore");
        builder.Append("&stm").Append("=").Append(1356663021692L);
        builder.Append("&key").Append("=").Append("AuENpLV5JiK5zTMirmS8ZG7hDaS1eSYi");
        builder.Append("&ssm").Append("=").Append(false);
        builder.Append("&vdm").Append("=").Append("all");
        builder.Append("&rvr").Append("=").Append("");
        builder.Append("&sce").Append("=").Append("iat");
        builder.Append("&ntt").Append("=").Append("wifi");
        builder.Append("&aue").Append("=").Append("speex-wb;7");
        builder.Append("&auf").Append("=").Append("audio/L16;source=outer;rate=16000");
        builder.Append("&ixid").Append("=").Append(1356663021692); //改为获取当前毫秒时间戳
        builder.Append("&pidx").Append("=").Append(1);
        builder.Append("&over").Append("=").Append(1);  

        List<IMultipartFormSection> requestData = new List<IMultipartFormSection>();
        requestData.Add(new MultipartFormDataSection ("param-data", builder.ToString()));
        requestData.Add (new MultipartFormFileSection ("voice-data", newSoundbyte));
        
		//添加你的lenovokey、secretkey、channel请求头
        Request request = new Request (URL)
            .AddHeader ("User-Agent", "{platform=[\"android4.2.5\"], name=[\"com.lenovo.leos.lestore\"], version=[\"1.0.1.130101_101\"]}")
            .Post (RequestBody.From(requestData)); 

        Client http = new Client ();
        yield return http.Send (request);
        ProcessResult (http);
    }

    void ProcessResult(Client http) {
        if (http.IsSuccessful ()) {
            Response resp = http.Response ();
            successText.text = "status: " + resp.Status().ToString() + "\nbody: " + resp.Body();
        } else {
            errorText.text = "error: " + http.Error();
        }
        StopCoroutine (ClearOutput ());
        StartCoroutine (ClearOutput ());
    }

    public void CreatePostWithFormData() {
        StartCoroutine (PostWithFormData ());
    }

    IEnumerator ClearOutput() {
        yield return new WaitForSeconds (2f);
        errorText.text = "";
        successText.text = "";
    }
}


        //param["param-data"] = builder.ToString();
        //param["voice-data"] = newSoundbyte;

        //FileStream fs = new FileStream("RECORDING.M4A", FileMode.Open);
        //param["voice-data"] = "5000" + fs;
        //Dictionary<string, string> param = new Dictionary<string, string>();