﻿using System.Collections;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using SimpleHTTP;
using UnityEngine.UI;
using UnityEngine.Networking;
using System;
using System.Text;



public class Main : MonoBehaviour {

	private Text errorText;
	private Text successText;
    private string URL = "https://voice.lenovomm.com/lasf/cloudasr";

	void Start () {
		errorText = GameObject.Find ("ErrorText").GetComponent<Text> ();
		successText = GameObject.Find ("SuccessText").GetComponent<Text> ();
	}

    IEnumerator PostWithFormData() {
        // This file recoding asks a simple question "What is your name?"
        byte[] soundbyte = File.ReadAllBytes("RECORDING.M4A");
        byte[] newSoundbyte = new byte[soundbyte.Length + 4];
        newSoundbyte[0] = 5;  
        newSoundbyte[1] = 0;
        newSoundbyte[2] = 0;
        newSoundbyte[3] = 0;
        soundbyte.CopyTo(newSoundbyte, 4);

        if (soundbyte == null) 
        {
            Debug.Log("ERROR! File is empty.");
        };
        
 

        List<IMultipartFormSection> requestData = new List<IMultipartFormSection>();
		//长语音long  短语音short
        requestData.Add(new MultipartFormDataSection ("scene", "cmd"));
		//sessionid	本次识别的标识    保证唯一的数字
		requestData.Add(new MultipartFormDataSection ("sessionid", "123123"));
		//在一次交互内的包的序列号   1
		requestData.Add(new MultipartFormDataSection ("packageid", "1"));
		//audioFormat	音频格式

		requestData.Add(new MultipartFormDataSection ("audioFormat", "pcm_16000_16bit_sample"));
		//	over	一次语音交互的完成标记（是否是最后一个包）
		//0不是尾包
		//1是尾包,并且正常结束
		//2是尾包,由于各种原因客户端主动结束语音操作
		requestData.Add(new MultipartFormDataSection ("over", "1"));
		
        requestData.Add (new MultipartFormFileSection ("voice-data", newSoundbyte));
        
		//添加你的lenovokey、secretkey、channel请求头
        Request request = new Request (URL)
            .AddHeader ("channel", "cloudasr")
			.AddHeader ("lenovokey", "")
			.AddHeader ("secretkey", "")
            .Post (RequestBody.From(requestData)); 

        Client http = new Client ();
        yield return http.Send (request);
        ProcessResult (http);
    }

    void ProcessResult(Client http) {
        if (http.IsSuccessful ()) {
            Response resp = http.Response ();
            successText.text = "status: " + resp.Status().ToString() + "\nbody: " + resp.Body();
        } else {
            errorText.text = "error: " + http.Error();
        }
        StopCoroutine (ClearOutput ());
        StartCoroutine (ClearOutput ());
    }

    public void CreatePostWithFormData() {
        StartCoroutine (PostWithFormData ());
    }

    IEnumerator ClearOutput() {
        yield return new WaitForSeconds (2f);
        errorText.text = "";
        successText.text = "";
    }
}


        //param["param-data"] = builder.ToString();
        //param["voice-data"] = newSoundbyte;

        //FileStream fs = new FileStream("RECORDING.M4A", FileMode.Open);
        //param["voice-data"] = "5000" + fs;
        //Dictionary<string, string> param = new Dictionary<string, string>();