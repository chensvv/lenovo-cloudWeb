#! /bin/bash

gcc tts_demo.c send_tts_data.c -o tts_demo -lcurl -lssl -lcrypto -lm