#include <stdio.h>
#include <stdlib.h>
#include "send_tts_data.h"
#include <string.h>
 
int main(int argc, char **argv)
{
		if(argc != 4)
		{
				fprintf(stderr, "%s\n", "Usage: text lenovoKey secretKey!");
      	return -1;
		}

		//lenovoKey （必填） 在官网注册获得
	    //secretKey （必填） 在官网注册获得
		//channel : （必填）官网注册得到的channel
		//text  （必填）    转换的文本内容

		// user（必填）  	用户accountid
   		char *user = "123456";
		 //audioType  音频种类   wav, mp3, pcm, pcm8； 默认mp3
		char *audioType = "mp3";

 		//speed 语速 在0~9之间（支持浮点值），不传时默认为5
		int speed = 5;
		 //volume 音量 在0~9之间（支持浮点值），不传时默认为5
		int volume = 5;
		//pitch  音调    在0~9之间（支持浮点值），不传时默认为5
		int pitch = 5;



		Init_Send_Tts_Data(argv[1], argv[2]);
		fprintf(stderr, "-----%s\n", argv[3]);
		Send_tts_data(argv[3],user,speed ,volume ,pitch,audioType );
		Send_Tts_Data_Delete();
		
		
		return 0;
}
