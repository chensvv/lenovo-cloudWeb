#include "send_tts_data.h"
#include "curl/curl.h"

#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <string.h>

struct curl_httppost* _formpost;
 struct curl_httppost* _lastptr;

#define POSTURL  "https://voice.lenovomm.com/lasf/cloudtts"

#define MAX_MSG 10240

char recv_buf[MAX_MSG + 1];
struct curl_slist* _headers;

CURL *_pcurl;
FILE *pFile = NULL;


size_t writedata2file(void *buffer, int size, int nmemb, void *stream) {

	memset( recv_buf, 0, sizeof(recv_buf));
	memcpy((void *)&recv_buf, buffer, (size_t)(size * nmemb));

	 size_t written = fwrite(recv_buf, size, nmemb, stream);
   return size * nmemb;
}

int Send_Tts_Data_Delete()
{
	printf("Send_CurlData_To_tts Free Begin!\n");
	  curl_slist_free_all(_headers);
	  curl_easy_cleanup(_pcurl);
	  curl_global_cleanup();
	  fclose(pFile);
	printf("Send_CurlData_To_tts Free End!\n");
}

int Init_Send_Tts_Data(char *lenovo_key, char *secret_key)
{
	    printf("Send_CurlData_To_tts Init Begin!\n");
		char l_key[47];
		char s_key[43];
		sprintf(l_key, "%s%s", "lenovoKey: ", lenovo_key);
		sprintf(s_key, "%s%s", "secretKey: ", secret_key);

		// 创建存语音的文件
		pFile = fopen("20220222.mp3", "wb");

	  /* 对编程环境进行相应的初始化 */
	  curl_global_init(CURL_GLOBAL_ALL);
	  /* 申请libcurl会话 */
	  _pcurl=curl_easy_init();
	  
	  //http 请求头 Must initialize
	  _headers = NULL;

	  //拼接 http 请求头
	//   _headers = curl_slist_append(_headers, "Accept-Encoding: gzip");
	  _headers = curl_slist_append(_headers, "channel: cloudtts");// channel : 官网注册得到的channel
	  _headers = curl_slist_append(_headers, l_key);  //
	  _headers = curl_slist_append(_headers, s_key);
	 
		//设置句柄值
	  curl_easy_setopt(_pcurl, CURLOPT_HTTPHEADER, _headers);
	  curl_easy_setopt(_pcurl, CURLOPT_URL, POSTURL);//URL地址
	  curl_easy_setopt(_pcurl, CURLOPT_POST, 1);//本次操作为POST
	  curl_easy_setopt(_pcurl, CURLOPT_SSL_VERIFYPEER, 0L); // https请求 不验证证书和hosts
      curl_easy_setopt(_pcurl, CURLOPT_SSL_VERIFYHOST, 0L);
    
      curl_easy_setopt(_pcurl, CURLOPT_NOSIGNAL, 1L);
	  //将返回结果通过回调函数写到自定义的对象中

      curl_easy_setopt(_pcurl, CURLOPT_WRITEDATA, pFile);
	  curl_easy_setopt(_pcurl, CURLOPT_WRITEFUNCTION, writedata2file);
	  curl_easy_setopt(_pcurl, CURLOPT_HEADER,0);
	  curl_easy_setopt(_pcurl, CURLOPT_VERBOSE,0);//不打印调试信息

		
		printf("Send_CurlData_To_tts Init End!\n");
		return 0;
}

int Send_tts_data(char *text,char *user ,int *speed, int *volume, int *pitch,char *audioType)
{
	
		_lastptr = NULL;
		_formpost = NULL;
		int ret_code = 0;
		char param_data[512];	
		sprintf(param_data, "text=%s&user=%s&speed=%ld&volume=%ld&pitch=%ld&audioType=%s", text, user,speed ,volume,pitch,audioType);

		fprintf(stderr, "text---: %s\n", text);
		fprintf(stderr, "param_data---: %s\n", param_data);				

		curl_formadd(&_formpost,  &_lastptr, CURLFORM_COPYNAME, "param-data", CURLFORM_COPYCONTENTS, param_data,  CURLFORM_CONTENTTYPE, "application/x-www-form-urlencoded", CURLFORM_END);

		curl_easy_setopt(_pcurl, CURLOPT_POSTFIELDS, param_data);

		/* 执行单条curl请求 */
		CURLcode ret_curl = curl_easy_perform(_pcurl);
		fprintf(stderr, "ret_curl---: %ld\n", ret_curl);
		if(ret_curl == CURLE_OK)
		{
			fprintf(stderr, "file save to : 20220222.mp3 \n");
		}
		else{
			fprintf(stderr,"Error: [%s]\n", curl_easy_strerror(ret_curl));
		    return -1;
		}

		fprintf(stderr, "-------end---------\n");
 		curl_formfree(_formpost);
		return 0;
}

 