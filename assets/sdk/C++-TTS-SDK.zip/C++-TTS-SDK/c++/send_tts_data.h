#ifndef SEND_CURLDATA_TO_ASR_H
#define SEND_CURLDATA_TO_ASR_H

		int Init_Send_Tts_Data(char *lenovo_key, char *secret_key);
		int Send_tts_data(char *text,char *user ,int *speed, int *volume, int *pitch,char *audioType);
		int Send_Tts_Data_Delete();
		
#endif //SEND_CURLDATA_TO_ASR_H