# coding=utf-8

import sys
import json
import base64
import time
import requests

IS_PY3 = sys.version_info.major == 3

if IS_PY3:
    from urllib.request import urlopen
    from urllib.request import Request
    from urllib.error import URLError
    from urllib.parse import urlencode

    timer = time.perf_counter
else:
    from urllib2 import urlopen
    from urllib2 import Request
    from urllib2 import URLError
    from urllib import urlencode

    if sys.platform == "win32":
        timer = time.clock
    else:
        # On most other platforms the best timer is time.time()
        timer = time.time

class DemoError(Exception):
    pass


if __name__ == '__main__':
    AUDIO_FILE = 'C:\\Users\\Music\\关闭抖音.wav'
    ASR_URL = 'https://voice.lenovomm.com/lasf/asr'
    speech_data = []
    with open(AUDIO_FILE, 'rb') as speech_file:
        speech_data = speech_file.read()

    length = len(speech_data)
    if length == 0:
        raise DemoError('file %s length read 0 bytes' % AUDIO_FILE)

    # data = {
    #     'stm': '1494237601458',
    #     'cpf': 'windows',
    #     'dtp':'motorola_ali',
    #     'ver':'2.1.0',
    #     'did':'270931c188c281ca',
    #     'uid':'37246729',
    #     'dev':'lenovo.ecs.vt',
    #     'app':'com.lenovo.menu_assistant',
    #     'ssm':'true',
    #     'vdm':'all',
    #     'rvr':'',
    #     'sce':'iat',
    #     'ntt':'wifi',
    #     'aue':'speex-wb;7',
    #     'auf':'audio%2FL16%3Brate%3D16000',
    #     'ixid':'1573536866258',
    #     'pidx':'1',
    #     'over':'1',
    #     'key':AuENpLV5JiK5zTMirmS8ZG7hDaS1eSYi
    # }
    param_data ="cpf=windows&dtp=motorola_ali&ver=2.1.0&did=270931c188c281ca&uid=37246729&dev=lenovo.ecs.vt&app=com.lenovo.menu_assistant&stm=1494237601458&ssm=true&vdm=all&rvr=&sce=iat&ntt=wifi&aue=speex-wb;7&auf=audio%2FL16%3Brate%3D16000%3Bsource%3Douter&ixid="+str(int(time.time()*1000))+"&pidx=1&over=1&key=AuENpLV5JiK5zTMirmS8ZG7hDaS1eSYi"
    files = {'voice-data': open(AUDIO_FILE, 'rb')}
    data ={
        'param-data': param_data
    }

    header = {'User-Agent':'{platform=["android4.2.5"], name=["com.lenovo.leos.lestore"], version=["1.0.1.130101_101"]}',
              'lenovokey':'',
              'secretkey':'',
              'channel':''
              }

    response = requests.post(ASR_URL, headers=header, data=data, files=files)
    print(response.text)


