# coding=utf-8

import sys
import json
import base64
import time
import requests

IS_PY3 = sys.version_info.major == 3

if IS_PY3:
    from urllib.request import urlopen
    from urllib.request import Request
    from urllib.error import URLError
    from urllib.parse import urlencode

    timer = time.perf_counter
else:
    from urllib2 import urlopen
    from urllib2 import Request
    from urllib2 import URLError
    from urllib import urlencode

    if sys.platform == "win32":
        timer = time.clock
    else:
        # On most other platforms the best timer is time.time()
        timer = time.time


class DemoError(Exception):
    pass


session = requests.Session()
session.mount('http://', requests.adapters.HTTPAdapter(pool_connections=1, pool_maxsize=20, max_retries=3))

#  详细解释请看 参数说明
header = {
        # （必填）   联想密钥   在官网注册获得
        'lenovokey': '',
        # （必填） 安全密钥     在官网注册获得
        'secretkey': '',
        # （必填）     请求来源
        'channel': 'cloudasr'
    }


def send(package, over, sid,data1):
    files = {'voice-data': data1}

    data = {
        'scene': "short",
        'sessionid': sid,  # int(time.time()*1000)
        'packageid': package,
        'audioFormat': "pcm_16000_16bit_sample",
        'over': over,
    }

    response = session.post(ASR_URL, headers=header, data=data, files=files)
    print(response.text)

    jsonstr = json.loads(response.text)
    print(jsonstr['rawType'] + "-------------" + jsonstr['rawText'])



def sendSubFile():
    speech_data = []
    pid = 0;
    sid=int(time.time() * 1000)
    with open(AUDIO_FILE, 'rb') as speech_file:
        while True:
            speech_data = speech_file.read(1024)
            pid += 1;

            if len(speech_data) == 0:
                send(pid, 1, sid,speech_data)
                break;

            send(pid, 0, sid,speech_data)


if __name__ == '__main__':
    AUDIO_FILE = 'C:\\Users\\Music\\关闭抖音.wav'
    ASR_URL = 'https://voice.lenovomm.com/lasf/cloudasr'

    sendSubFile();

