#include <stdio.h>
#include <stdlib.h>
#include "send_asr_data.h"
#include <sys/time.h>

long Packets_nm = 0;    //curl 发送引擎语音数据包的序号
int asr_data_len = 16000;

FILE *asr_fp = NULL;

int main(int argc, char **argv)
{
		if(argc != 3)
		{
				fprintf(stderr, "%s\n", "Usage:lenovoKey secretKey!");
      	return -1;
		}
		
		int read_len = 0;
		char *asr_data_buffer;
		asr_data_buffer = (char *)malloc((asr_data_len+4) * sizeof(char));
		if(asr_data_buffer == NULL)
		{
    		fprintf(stderr,"malloc buf:%s error!\n", "asr_data_buffer");
      	return -1;
    }
    bzero(asr_data_buffer, asr_data_len + 4);
		/* 音频数据以5000开头 */
		asr_data_buffer[0]=5;
		asr_data_buffer[1]=0;
		asr_data_buffer[2]=0;
		asr_data_buffer[3]=0;
		
		if( (asr_fp = fopen("asr_demo.pcm", "rb+")) == NULL )
		{
        fprintf(stderr,"Fail To Open %s!\n", "asr_demo.pcm");
    		return -1;
    }
   
		Init_Send_Asr_Data(argv[1], argv[2]);
		  	struct timeval tv;
		gettimeofday(&tv,NULL);
		char _curl_stime[18];
		long long stmm = (long long)tv.tv_sec*1000 + tv.tv_usec/1000;
		memset( _curl_stime, 0, sizeof(_curl_stime));
  		sprintf(_curl_stime, "%lld", stmm);
		printf("_curl_stime----:%s\n", _curl_stime);

		while(1)
		{
				memset( asr_data_buffer+4, 0, asr_data_len );
	      
	      read_len = fread(asr_data_buffer, 1, asr_data_len, asr_fp);
	      Packets_nm++;
				Sending_asr_data(asr_data_buffer, asr_data_len+4, Packets_nm, 0,_curl_stime);
				
				if(feof(asr_fp))
        {
        		Packets_nm++;
        		memset( asr_data_buffer+4, 0, asr_data_len );
        		Sending_asr_data(asr_data_buffer, asr_data_len+4, Packets_nm, 1,_curl_stime);
        		printf("asr_demo.pcm read Over!\n");
        		break;
        }
        
		}
		
		Send_Asr_Data_Delete();
		
		free(asr_data_buffer);
		fclose(asr_fp);
		return 0;
}
