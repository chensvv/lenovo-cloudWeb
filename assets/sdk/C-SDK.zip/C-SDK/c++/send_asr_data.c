#include "send_asr_data.h"
#include "curl/curl.h"
#include "cJSON.h"

#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <string.h>

// #define POSTURL  "https://voice.lenovomm.com/lasf/cloudasr"
#define POSTURL  "http://10.110.148.59:8082/lasf/cloudasr"
#define MAX_MSG 2048

char _curl_stime[14];
char recv_buf[MAX_MSG + 1];
struct curl_slist* _headers;
struct curl_httppost* _formpost;
struct curl_httppost* _lastptr;
struct curl_slist* _list_par;
struct curl_slist* _list_voi;

CURL *_pcurl;

cJSON *_ret_cjson_parse;
cJSON *_ret_cjson_item;
	
int write_data(void* buffer, int size, int nmemb, void **stream)
{
  memset( recv_buf, 0, sizeof(recv_buf));
	memcpy((void *)&recv_buf, buffer, (size_t)(size * nmemb));
  return size * nmemb;
}

int Send_Asr_Data_Delete()
{
	printf("Send_CurlData_To_Asr Free Begin!\n");
	  curl_slist_free_all(_headers);
	  curl_slist_free_all(_list_par);
	  curl_slist_free_all(_list_voi);
	  curl_easy_cleanup(_pcurl);
	  curl_global_cleanup();
	printf("Send_CurlData_To_Asr Free End!\n");
}

int Init_Send_Asr_Data(char *lenovo_key, char *secret_key)
{
	printf("Send_CurlData_To_Asr Init Begin!\n");
		char l_key[47];
		char s_key[43];
		sprintf(l_key, "%s%s", "lenovoKey: ", lenovo_key);
		sprintf(s_key, "%s%s", "secretKey: ", secret_key);
		
  	/* 获取当前系统时间，精确到毫秒 */
  	struct timeval tv;
		gettimeofday(&tv,NULL);
		long long stmm = (long long)tv.tv_sec*1000 + tv.tv_usec/1000;
		memset( _curl_stime, 0, sizeof(_curl_stime));
  	sprintf(_curl_stime, "%lld", stmm);
		printf("_curl_stime----:%s\n", _curl_stime);
	  
	  /* 对编程环境进行相应的初始化 */
	  curl_global_init(CURL_GLOBAL_ALL);
	  
	  /* 申请libcurl会话 */
	  _pcurl=curl_easy_init();
	  
	  //http 请求头 Must initialize
	  _headers = NULL;
	  _list_par = NULL;
		_list_voi = NULL;
		
	  //拼接 http 请求头
	  _headers = curl_slist_append(_headers, "Accept-Encoding: gzip");
	  _headers = curl_slist_append(_headers, "channel: cloudasr");
	  _headers = curl_slist_append(_headers, l_key);
	 	_headers = curl_slist_append(_headers, s_key);
	 
		//设置句柄值
	  curl_easy_setopt(_pcurl, CURLOPT_HTTPHEADER, _headers);
	  curl_easy_setopt(_pcurl, CURLOPT_URL, POSTURL);//URL地址
	  curl_easy_setopt(_pcurl, CURLOPT_POST, 1);//本次操作为POST
	  curl_easy_setopt(_pcurl, CURLOPT_SSL_VERIFYPEER, 0L); // https请求 不验证证书和hosts
    curl_easy_setopt(_pcurl, CURLOPT_SSL_VERIFYHOST, 0L);
    
    curl_easy_setopt(_pcurl, CURLOPT_NOSIGNAL, 1L);
	  //将返回结果通过回调函数写到自定义的对象中
	  curl_easy_setopt(_pcurl, CURLOPT_WRITEFUNCTION, write_data);
	  curl_easy_setopt(_pcurl, CURLOPT_HEADER,0);
	  curl_easy_setopt(_pcurl, CURLOPT_VERBOSE,0);//不打印调试信息

    _list_par = curl_slist_append(_list_par, "Content-Transfer-Encoding: 8bit");
		_list_voi = curl_slist_append(_list_voi, "Content-Transfer-Encoding: binary");
		
		printf("Send_CurlData_To_Asr Init End!\n");
		return 0;
}

int Sending_asr_data(char *buffernew_curl, int count_nm, long Packets_nm, int vad_fg,long session)
{
		int ret_code = 0;
		char str_rawText[2048];
		char str_rawType[50];
		
		char scene="cmd";
  		char audioFormat= "pcm_16000_16bit_sample";

		memset( str_rawType, 0, sizeof(str_rawType) );
		memset( str_rawText, 0, sizeof(str_rawText) );

		_lastptr = NULL;
		_formpost = NULL;
		

		curl_formadd(&_formpost, &_lastptr, CURLFORM_COPYNAME, "scene", CURLFORM_COPYCONTENTS, scene, CURLFORM_CONTENTHEADER, _list_par, CURLFORM_CONTENTTYPE, "text/plain; charset=UTF-8", CURLFORM_END);

		curl_formadd(&_formpost, &_lastptr, CURLFORM_COPYNAME, "sessionid", CURLFORM_COPYCONTENTS, session, CURLFORM_CONTENTHEADER, _list_par, CURLFORM_CONTENTTYPE, "text/plain; charset=UTF-8", CURLFORM_END);

		curl_formadd(&_formpost, &_lastptr, CURLFORM_COPYNAME, "packageid", CURLFORM_COPYCONTENTS, Packets_nm, CURLFORM_CONTENTHEADER, _list_par, CURLFORM_CONTENTTYPE, "text/plain; charset=UTF-8", CURLFORM_END);

		curl_formadd(&_formpost, &_lastptr, CURLFORM_COPYNAME, "audioFormat", CURLFORM_COPYCONTENTS, audioFormat, CURLFORM_CONTENTHEADER, _list_par, CURLFORM_CONTENTTYPE, "text/plain; charset=UTF-8", CURLFORM_END);

		curl_formadd(&_formpost, &_lastptr, CURLFORM_COPYNAME, "over", CURLFORM_COPYCONTENTS, vad_fg, CURLFORM_CONTENTHEADER, _list_par, CURLFORM_CONTENTTYPE, "text/plain; charset=UTF-8", CURLFORM_END);

		/* 上传自定义文件内容的文件，CURLFORM_BUFFER指定服务端文件名 */
		curl_formadd(&_formpost, &_lastptr, CURLFORM_COPYNAME, "voice-data", CURLFORM_BUFFER, "voice.dat", CURLFORM_BUFFERPTR, buffernew_curl, CURLFORM_BUFFERLENGTH, count_nm, CURLFORM_CONTENTHEADER, _list_voi, CURLFORM_CONTENTTYPE, "application/i7-voice", CURLFORM_END);

		curl_easy_setopt(_pcurl, CURLOPT_HTTPPOST, _formpost);
		/* 执行单条curl请求 */
		CURLcode ret_curl = curl_easy_perform(_pcurl);
		if(ret_curl != CURLE_OK)
		{
				fprintf(stderr,"Error: [%s]\n", curl_easy_strerror(ret_curl));
		    curl_formfree(_formpost);
		    return -1;
		}
		
		/* 获取服务器响应码 */
		ret_curl = curl_easy_getinfo(_pcurl, CURLINFO_RESPONSE_CODE, &ret_code);
		//printf("ret_curl:%d\n", ret_curl);
		if((CURLE_OK == ret_curl) && ret_code == 200)
		{
			  /* 将接收到的数据转换为 cjson 对象，该函数会通过malloc()函数在内存中开辟一个空间，使用完成需要手动释放 */
			  _ret_cjson_parse = cJSON_Parse((char *)recv_buf);
			  if (!_ret_cjson_parse)  
			  {
			    fprintf(stderr,"Error before: [%s]\n", cJSON_GetErrorPtr());
			    curl_formfree(_formpost);
			    return -1;
			  }
			  
			  _ret_cjson_item = cJSON_GetObjectItem(_ret_cjson_parse, "rawType");
        if( _ret_cjson_item != NULL )
        {
          memset(str_rawType, 0, sizeof(str_rawType));
        	sprintf( str_rawType, "%s", _ret_cjson_item->valuestring);
        	_ret_cjson_item = cJSON_GetObjectItem(_ret_cjson_parse, "rawText"); 

          memset(str_rawText, 0, sizeof(str_rawText));
          sprintf( str_rawText, "%s", _ret_cjson_item->valuestring);
          printf("%s:%s\n", str_rawType, str_rawText);
        }
		}
		else
		{
		  fprintf(stderr, "Send_CurlData_To_Asr curl_easy_getinfo failed: %s\n", curl_easy_strerror(ret_curl));
		  curl_formfree(_formpost);
		  return -1;
		}
		
		cJSON_Delete(_ret_cjson_parse);
		curl_formfree(_formpost);
		return 0;
}
