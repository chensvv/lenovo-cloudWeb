#! /bin/bash

gcc asr_demo.c send_asr_data.c cJSON.c -o asr_demo -lcurl -lssl -lcrypto -lm