#ifndef SEND_CURLDATA_TO_ASR_H
#define SEND_CURLDATA_TO_ASR_H

		int Init_Send_Asr_Data(char *lenovo_key, char *secret_key);
		int Sending_asr_data(char *buffernew_curl, int count_nm, long Packets_nm, int vad_fg);
		int Send_Asr_Data_Delete();
		
#endif //SEND_CURLDATA_TO_ASR_H