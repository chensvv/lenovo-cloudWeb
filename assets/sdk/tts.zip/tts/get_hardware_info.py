import os
import base64
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_v1_5 as PKCS1_cipher

CURRENT_FILE_PATH = os.path.abspath(__file__)
CURRENT_DIR = os.path.dirname(CURRENT_FILE_PATH)

key_path = os.path.join(CURRENT_DIR, "Hard.info")
public_key_path = os.path.join(CURRENT_DIR, "public_key.pem")


def get_hardware_info():
    return os.popen("sudo cat /sys/class/dmi/id/product_uuid").read().strip()


def get_key(file):
    with open(file) as f: r = f.read()
    key = RSA.importKey(r)
    return key


def encrypt_data(msg):
    public_key = get_key(public_key_path)
    cipher = PKCS1_cipher.new(public_key)
    encrypt_text = base64.b64encode(cipher.encrypt(bytes(msg.encode("utf8"))))
    return encrypt_text.decode("utf-8")


def write_key():
    msg = get_hardware_info()
    res = encrypt_data(msg)
    with open(key_path, "wb") as fw: fw.write(res.encode())


if __name__ == "__main__":
    write_key()
