package com.lenovo.tts;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

public class JavaCloudTTSClient {
    static String url = "https://voice.lenovomm.com/lasf/cloudtts";

    private void cloudTTS(String content){
        HttpClient httpClient   = HttpClients.createDefault();
        HttpResponse httpResponse = null;
        try {
            HttpPost httpPost = new HttpPost(url);
            RequestConfig requestConfig = RequestConfig.custom().
                    setSocketTimeout(60000).
                    setConnectTimeout(60000).
                    build();
            httpPost.setConfig(requestConfig);

            List<BasicHeader> basicHeaders = new ArrayList<>();

            BasicHeader[] basics = new BasicHeader[basicHeaders.size()];

            BasicHeader header = new BasicHeader("channel", "");
            basicHeaders.add(header);
            header = new BasicHeader("lenovokey", "");
            basicHeaders.add(header);
            header = new BasicHeader("secretkey", "");
            basicHeaders.add(header);

            basics = basicHeaders.toArray(basics);

            if(basics!=null && basics.length>0){
                httpPost.setHeaders(basics);
            }
            List<NameValuePair> pairs = new ArrayList<>();
            pairs.add(new BasicNameValuePair("text", content));
            pairs.add(new BasicNameValuePair("user","123456"));

            UrlEncodedFormEntity entity = new UrlEncodedFormEntity(pairs,"UTF-8");
            httpPost.setEntity(entity);
            httpResponse = httpClient.execute(httpPost);
            if(httpResponse.getStatusLine().getStatusCode() != HttpStatus.SC_OK){
                return;
            }
            FileOutputStream fos = new FileOutputStream("E:\\voice\\20210330.pcm");
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            httpResponse.getEntity().writeTo(bos);
            fos.write(bos.toByteArray());
            bos.close();
            fos.flush();
            fos.close();

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void main(String[] args) {
        JavaCloudTTSClient javaCloudTTSClient = new JavaCloudTTSClient();
        javaCloudTTSClient.cloudTTS("今天天气怎么样");
    }
}
