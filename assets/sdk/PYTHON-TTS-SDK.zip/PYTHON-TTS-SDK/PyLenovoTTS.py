# coding=utf-8

import sys
import time
import requests

IS_PY3 = sys.version_info.major == 3

if IS_PY3:
    from urllib.request import urlopen
    from urllib.request import Request
    from urllib.error import URLError
    from urllib.parse import urlencode

    timer = time.perf_counter
else:
    from urllib2 import urlopen
    from urllib2 import Request
    from urllib2 import URLError
    from urllib import urlencode

    if sys.platform == "win32":
        timer = time.clock
    else:
        # On most other platforms the best timer is time.time()
        timer = time.time


class DemoError(Exception):
    pass


if __name__ == '__main__':

    ASR_URL = "https://voice.lenovomm.com/lasf/cloudtts"

    #  参数
    data = {
        #（必填）  转换的文本内容
        'text': '今天天气怎么样',
        #（必填）用户accountid
        'user': '123456',
        # speed 语速 在0~9之间（支持浮点值），不传时默认为5
        'speed': '5',
        # volume 音量 在0~9之间（支持浮点值），不传时默认为5
        'volume': '5',
        # pitch  音调    在0~9之间（支持浮点值），不传时默认为5
        'pitch': '5',
        # audioType  音频种类   wav, mp3, pcm, pcm8； 默认mp3
        'audioType': 'mp3'
    }

    header = {
        #（必填）   联想密钥   在官网注册获得
        'lenovokey': '',
        # （必填） 安全密钥     在官网注册获得
        'secretkey': '',
        # （必填）     请求来源 在官网注册获得
        'channel': ''
    }

    response = requests.post(ASR_URL, headers=header, data=data)

    AUDIO_FILE = "E:\\20220221.mp3"
    with open(AUDIO_FILE, "wb")as w:
        w.write(response.content)

