package com.test.cloud;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class JavaCloudTTSClient {
    static String url = "https://voice.lenovomm.com/lasf/cloudtts";

    private void cloudTTS(String content){
        HttpClient httpClient   = HttpClients.createDefault();
        HttpResponse httpResponse = null;
        FileOutputStream fos = null;
        try {
            HttpPost httpPost = new HttpPost(url);
            RequestConfig requestConfig = RequestConfig.custom().
                    setSocketTimeout(60000).
                    setConnectTimeout(60000).
                    build();
            httpPost.setConfig(requestConfig);

            List<BasicHeader> basicHeaders = new ArrayList<>();

            BasicHeader[] basics = new BasicHeader[basicHeaders.size()];
            //（必填） 使用来源
            BasicHeader header = new BasicHeader("channel", "cloudtts");
            basicHeaders.add(header);

            //（必填） 联想密钥 在官网注册获得
            header = new BasicHeader("lenovokey", "");
            basicHeaders.add(header);
            //（必填） 安全密钥 在官网注册获得
            header = new BasicHeader("secretkey", "");
            basicHeaders.add(header);

            basics = basicHeaders.toArray(basics);

            if(basics!=null && basics.length>0){
                httpPost.setHeaders(basics);
            }
            List<NameValuePair> pairs = new ArrayList<>();
            // （必填）    转换的文本内容
            pairs.add(new BasicNameValuePair("text", content));
            // （必填）  	用户accountid
            pairs.add(new BasicNameValuePair("user","123456"));

            //speed 语速 在0~9之间（支持浮点值），不传时默认为5
            pairs.add(new BasicNameValuePair("speed","5"));

            //volume 音量 在0~9之间（支持浮点值），不传时默认为5
            pairs.add(new BasicNameValuePair("volume","5"));
            //pitch  音调    在0~9之间（支持浮点值），不传时默认为5
            pairs.add(new BasicNameValuePair("pitch","5"));
            //audioType  音频种类   wav, mp3, pcm, pcm8； 默认mp3
            pairs.add(new BasicNameValuePair("audioType","mp3"));

            UrlEncodedFormEntity entity = new UrlEncodedFormEntity(pairs,"UTF-8");

            httpPost.setEntity(entity);
            httpResponse = httpClient.execute(httpPost);
            if(httpResponse.getStatusLine().getStatusCode() != HttpStatus.SC_OK){
                System.out.println("请求异常，状态码："+httpResponse.getStatusLine().getStatusCode());
                return;
            }

            fos = new FileOutputStream("E:\\20220221.mp3");
            httpResponse.getEntity().writeTo(fos);

            // 测试时，如果输出的音频无法播放，可以用文本打开此文件查看异常信息
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ClientProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
          if (fos!=null) {
              try {
                  fos.close();
              } catch (IOException e) {
                  e.printStackTrace();
              }
          }

        }

    }

    public static void main(String[] args) {
        JavaCloudTTSClient javaCloudTTSClient = new JavaCloudTTSClient();
        javaCloudTTSClient.cloudTTS("今天天气怎么样");

    }
}
