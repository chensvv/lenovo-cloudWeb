var chunkInfo;
var rec;
var wave
var ixid = new Date().getTime();
var urlInfo = 'https://voice.lenovomm.com/website/cloudasr'
var accountid = '10140802691'; //官网获取
var lenkey = 'LENOVO-VOICE-25c705e83m8865da1l7ac6d'; //官网获取
var secrkey = '266AC5CAC135A2221A0D8D9CBC896F4F'; //官网获取
var samp = 16000 //8000
var lang = 'chinese' //english
function record(e) {
    var img_btn = document.getElementById('record');
    var statusP = document.getElementById("status");
    if (e.classList.contains("recording")) {
        img_btn.src = 'images/Mic-nor.png';
        e.classList.remove("recording");
        statusP.innerHTML = '正在识别语音......';
        recStop()
    } else {
        e.classList.add("recording");
        statusP.innerHTML = '请说话';
        img_btn.src = 'images/Mic-act.png';
        recOpen()
    }
}

function recOpen(success) {
    rec = Recorder({
        type: "wav",
        sampleRate: samp,
        bitRate: 16,
        onProcess: function (buffers, powerLevel, bufferDuration, bufferSampleRate) {
            //wave.input(buffers[buffers.length-1],powerLevel,bufferSampleRate);//输入音频数据，更新显示波形
        }
    });

    //var dialog=createDelayDialog(); 我们可以选择性的弹一个对话框：为了防止移动端浏览器存在第三种情况：用户忽略，并且（或者国产系统UC系）浏览器没有任何回调，此处demo省略了弹窗的代码
    rec.open(function () { //打开麦克风授权获得相关资源
        //dialog&&dialog.Cancel(); 如果开启了弹框，此处需要取消
        //开始录音
        chunkInfo = null //长语音需在开始录音时置空chunkInfo
        rec.start() //此处可以立即开始录音，但不建议这样编写，因为open是一个延迟漫长的操作，通过两次用户操作来分别调用open和start是推荐的最佳流程
        success && success();
    }, function (msg, isUserNotAllow) { //用户拒绝未授权或不支持
        //dialog&&dialog.Cancel(); 如果开启了弹框，此处需要取消
        // console.log((isUserNotAllow?"UserNotAllow，":"")+"无法录音:"+msg);
        alert("无法录音:" + msg)
    });
};

function recStop() {
    rec.stop(function (blob, duration) {
        // console.log(blob,(window.URL||webkitURL).createObjectURL(blob),"时长:"+duration+"ms");
        rec.close(); //释放录音资源，当然可以不释放，后面可以连续调用start；但不释放时系统或浏览器会一直提示在录音，最佳操作是录完就close掉
        rec = null;
        var reader = new FileReader();
        reader.readAsArrayBuffer(blob, 'utf-8');
        reader.onload = function (e) {
            var buf = new Uint16Array(reader.result);
            var buf2 = [];
            Object.assign(buf2, buf);
            // 首包发送数据必须发送：比特率8000(1, 0, 0, 0)、比特率16000(5, 0, 0, 0)
            if (samp == '8000') {
                buf2.unshift(1, 0, 0, 0);
            } else {
                buf2.unshift(5, 0, 0, 0);
            }
            var buf4 = new Uint16Array(buf2);
            var formData = new FormData();
            var ixid = new Date().getTime();
            formData.append("scene", 'short'); //场景：short:短语音，long:长语音
            formData.append("language", lang); //语言:英文识别english,不传或其它值默认中文
            formData.append("sample", '1'); //通道数:八通道值为8,不传或其他值默认1
            formData.append("audioFormat", 'pcm_' + samp + '_16bit_sample'); //比特率: 16000 8000
            formData.append("sessionid", ixid); //系统时间戳
            formData.append("packageid", "1"); //短语音默认1；长语音模式下每个会话数字从1开始迭代
            formData.append("over", "1"); //短语音模式默认1；长语音模式下:0未结束,1结束，每次结束必须发送一次over值为1的尾包
            formData.append("voice-data", new Blob([buf4])); //语音数据
            $.ajax({
                type: "post",
                url: urlInfo,
                data: formData,
                headers: {
                    'channel': 'cloudasr',
                    'lenovokey': lenkey,
                    'secretkey': secrkey
                },
                contentType: false,
                processData: false,
                success: function (result) {
                    $('#status').html(result.rawText)
                    // 详细参数请参照官网API文档
                }
            });
        }
    }, function (msg) {
        alert("录音失败:" + msg);
        rec.close(); //可以通过stop方法的第3个参数来自动调用close
        rec = null;
    });
};