package com.lenovo.lasf.framework.test;

import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ByteArrayBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;


public class JavaASRHttpClient {

	static String CONTENT_TYPE = "audio/L16;rate=16000";
	static String paramName = "param-data";
	static String voiceName = "voice-data";
	public static boolean isOuter =false;
	static String url = "https://voice.lenovo.com/lasf/asr";

	//发送http请求
    @SuppressWarnings("deprecation")
	protected static String asrPostMultiPartFile(String url, Header[] headers, String params,  byte[] voice) {
        HttpClient   httpClient   = HttpClients.createDefault();
        String       responseText = "";
        HttpResponse httpResponse = null;
 
        try {
            HttpPost httpPost = new HttpPost(url);
            RequestConfig requestConfig = RequestConfig.custom().
                    setSocketTimeout(180000).
                    setConnectTimeout(180000).
                    build();
            httpPost.setConfig(requestConfig);
 
            if(headers!=null && headers.length>0){
            	httpPost.setHeaders(headers);
            }
            
            MultipartEntity me = new MultipartEntity();
            me.addPart(paramName,new StringBody(params,Charset.forName("UTF-8")));
            
            if(isOuter){
	            ByteArrayBody byteBody = new ByteArrayBody(voice, "hello.pcm");
	            me.addPart(voiceName, byteBody);
            }else {
				byte[] final_data = null;
				if(params.contains("pidx=1")){
					final_data = new byte[voice.length + 4];

					final_data[0] = 5;
					final_data[1] = 0;
					final_data[2] = 0;
					final_data[3] = 0;
					System.arraycopy(voice, 0, final_data, 4, voice.length);
			    }else{
					final_data = voice;
				}

	            ByteArrayBody byteBody = new ByteArrayBody(final_data, "hello.pcm");
	            me.addPart(voiceName, byteBody);

            }
            
            httpPost.setEntity(me);

            httpResponse = httpClient.execute(httpPost);
            
            if (httpResponse.getStatusLine().getStatusCode() == 200) {
                responseText = EntityUtils.toString(httpResponse.getEntity());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
 
        return responseText;
    }


    public String recogniseNormal(byte[] filePath, String contentType,boolean isChinese){
    	return recogniseSub(filePath, contentType, System.currentTimeMillis(), 1L, true, isChinese);
    }

    //设置请求参数
	public String recogniseSub(byte[] filePath, String contentType, long sessionid, long packageNum, boolean isEnd,boolean isChinese){
		
		List<BasicHeader> basicHeaders = new ArrayList<BasicHeader>();
		BasicHeader header = new BasicHeader("User-Agent", "{platform=[\"android4.2.5\"], name=[\"com.lenovo.leos.lestore\"], version=[\"1.0.1.130101_101\"]}");
		basicHeaders.add(header);
		
    	BasicHeader[] basics = new BasicHeader[basicHeaders.size()];

		header = new BasicHeader("channel", "");
		basicHeaders.add(header);

		header = new BasicHeader("lenovokey", "");
		basicHeaders.add(header);
		
		header = new BasicHeader("secretkey", "");
		basicHeaders.add(header);

    	basics = basicHeaders.toArray(basics);

    	StringBuffer sb = new StringBuffer();
    	Random random = new Random();
    	sb.append("cpf").append("=").append("windows");
    	sb.append("&dtp").append("=").append("iO2S");
    	sb.append("&ver").append("=").append("1.1.9");
    	sb.append("&did").append("=").append("270931c188c281ca");
    	sb.append("&uid").append("=").append(random.nextInt(10000000));
    	sb.append("&dev").append("=").append("lenovo.ecs.vt");
    	sb.append("&app").append("=").append("com.lenovo.menu_assistant");
    	sb.append("&stm").append("=").append(1494237601458L);
    	sb.append("&key").append("=").append("0ekT/KgQg8uel9nIkTyi1BuBfTU59TKTvAuENpLV5JiK5zTMirmS8ZG7hDaS1eSYiu");
    	sb.append("&ssm").append("=").append(true);
    	sb.append("&vdm").append("=").append("all");
    	sb.append("&rvr").append("=").append("");
    	sb.append("&sce").append("=").append("iat"); //长语音
    	sb.append("&ntt").append("=").append("wifi");
    	sb.append("&aue").append("=").append("speex-wb;7");
    	sb.append("&auf").append("=").append(URLEncoder.encode(contentType));
    	sb.append("&ixid").append("=").append(sessionid);
    	sb.append("&pidx").append("=").append(packageNum);
    	sb.append("&over").append("=").append(isEnd?1:0);
    	return asrPostMultiPartFile(url, basics, sb.toString(), filePath);

	}

	//文件读为byte数组
	protected byte[] getSourceData(String filePath) {
		byte[] src_data = null;
		try{
	        File file = new File(filePath);
	        FileInputStream inputStream = new FileInputStream(file);
	        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
	        byte[] array = new byte[512];
	        int n;
	        while((n=inputStream.read(array))!=-1){
	        	outputStream.write(array);
	        }
	        
	        src_data = outputStream.toByteArray();
	        
	        outputStream.flush();
	        outputStream.close();
	        inputStream.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return src_data;
	}
	
	private void sendFile(String path, boolean isChinese){
		byte[] data = getSourceData(path);
		String res = recogniseNormal(data, CONTENT_TYPE, isChinese);

		System.out.println("结果:"+res);
		JSONObject js = JSONObject.fromObject(res);
		System.out.print(path + "\t" + (js==null?"":js.get("rawText")));
	}


	private void sendSubFile(String path, int num, boolean isChinese) throws IOException {


        String res = "";
        long sessionid = System.currentTimeMillis();

        try{
            File file = new File(path);
            FileInputStream inputStream = new FileInputStream(file);
            Random random = new Random();
            byte[] array = new byte[1024];
            int n, i=1;
            while((n=inputStream.read(array))!=-1){
                res = recogniseSub(Arrays.copyOfRange(array,0,n),CONTENT_TYPE , sessionid, i++, false,isChinese);

                JSONObject js = JSONObject.fromObject(res);
				System.out.println(js.toString());
                if(js.get("rawText")!=null && StringUtils.isNotBlank(js.get("rawText").toString())) {
                        System.out.println(js.get("rawType") + "        " + js.get("rawText"));
                }
            }
            System.out.println("package numbers: " + i);
            res = recogniseSub(new byte[0],CONTENT_TYPE , sessionid, i, true,isChinese);
            JSONObject js = JSONObject.fromObject(res);
			System.out.println("fianl result: " + js.toString());
            inputStream.close();
        }catch (Exception e) {
            e.printStackTrace();
        }
	}



	public static void main(String[] args) throws IOException {
		JavaASRHttpClient client = new JavaASRHttpClient();
		client.sendFile("C:\\Users\\Music\\关闭抖音.wav", true);
    }

}
