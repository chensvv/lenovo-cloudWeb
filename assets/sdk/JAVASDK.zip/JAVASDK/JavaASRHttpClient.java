package com.test.cloud;

import net.sf.json.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ByteArrayBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.util.*;


public class JavaASRHttpClient {

	static String CONTENT_TYPE = "pcm_16000_16bit_sample";
	static String voiceName = "voice-data";
	public static boolean isOuter =false;
	static HttpClient   httpClient   = HttpClients.createDefault();
	//发送http请求
    @SuppressWarnings("deprecation")
	protected static String asrPostMultiPartFile(String url, Header[] headers,HashMap<String, String> params,  byte[] voice) {

        String       responseText = "";
        HttpResponse httpResponse = null;

        try {
            HttpPost httpPost = new HttpPost(url);
            RequestConfig requestConfig = RequestConfig.custom().
                    setSocketTimeout(180000).
                    setConnectTimeout(180000).
                    build();
            httpPost.setConfig(requestConfig);

            if(headers!=null && headers.length>0){
            	httpPost.setHeaders(headers);
            }

            MultipartEntity me = new MultipartEntity();

			for (Map.Entry<String, String> entry : params.entrySet()) {
				me.addPart(entry.getKey(),new StringBody(entry.getValue(),Charset.forName("UTF-8")));
			}

            if(isOuter){
	            ByteArrayBody byteBody = new ByteArrayBody(voice, "hello.pcm");
	            me.addPart(voiceName, byteBody);
            }else {
				byte[] final_data = null;
				if(params.get("packageid").equals("1")){
					final_data = new byte[voice.length + 4];

					final_data[0] = 5;
					final_data[1] = 0;
					final_data[2] = 0;
					final_data[3] = 0;
					System.arraycopy(voice, 0, final_data, 4, voice.length);
			    }else{
					final_data = voice;
				}

	            ByteArrayBody byteBody = new ByteArrayBody(final_data, "hello.pcm");
	            me.addPart(voiceName, byteBody);

            }

            httpPost.setEntity(me);

            httpResponse = httpClient.execute(httpPost);

            if (httpResponse.getStatusLine().getStatusCode() == 200) {
                responseText = EntityUtils.toString(httpResponse.getEntity());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return responseText;
    }


    public String recogniseNormal(byte[] filePath, String contentType,boolean isChinese){
    	return recogniseSub(filePath, contentType, System.currentTimeMillis(), 1L, true, isChinese);
    }

    //设置请求参数
	public String recogniseSub(byte[] filePath, String contentType, long sessionid, long packageNum, boolean isEnd,boolean isChinese){

		List<BasicHeader> basicHeaders = new ArrayList<BasicHeader>();


    	BasicHeader[] basics = new BasicHeader[basicHeaders.size()];

		BasicHeader header = new BasicHeader("channel", "cloudasr");
		basicHeaders.add(header);
//		官网注册获得
		header = new BasicHeader("lenovokey", "");
		basicHeaders.add(header);
//		官网注册获得
		header = new BasicHeader("secretkey", "");
		basicHeaders.add(header);

    	basics = basicHeaders.toArray(basics);

		HashMap<String, String> map = new HashMap<>();
//		短语应  short    长语音 long
		map.put("scene","long");
		// sessionid  随机数字 （须唯一）
		map.put("sessionid",sessionid+"");
		// 在一次交互内的包的序列号
		map.put("packageid",packageNum+"");
		//音频格式
		map.put("audioFormat",URLEncoder.encode(contentType));
		//一次语音交互的完成标记（是否是最后一个包）
		//	0不是尾包
		//	1是尾包,并且正常结束
		//	2是尾包,由于各种原因客户端主动结束语音操作.
		map.put("over",isEnd?"1":"0");

    	return asrPostMultiPartFile(url, basics, map, filePath);

	}

	//文件读为byte数组
	protected byte[] getSourceData(String filePath) {
		byte[] src_data = null;
		try{
	        File file = new File(filePath);
	        FileInputStream inputStream = new FileInputStream(file);
	        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
	        byte[] array = new byte[512];
	        int n;
	        while((n=inputStream.read(array))!=-1){
	        	outputStream.write(array);
	        }

	        src_data = outputStream.toByteArray();

	        outputStream.flush();
	        outputStream.close();
	        inputStream.close();
		}catch (Exception e) {
			e.printStackTrace();
		}

		return src_data;
	}

	private void sendFile(String path, boolean isChinese){
		byte[] data = getSourceData(path);
		String res = recogniseNormal(data, CONTENT_TYPE, isChinese);

		System.out.println("结果:"+res);
		JSONObject js = JSONObject.fromObject(res);
		System.out.print(path + "\t" + (js==null?"":js.get("rawText")));
	}


	private void sendSubFile(String path,  boolean isChinese) throws IOException {
        String res = "";
		Random random1 = new Random();
		long sessionid =  random1.nextInt(999); //;

         try{
            File file = new File(path);
            FileInputStream inputStream = new FileInputStream(file);

            byte[] array = new byte[1024];
            int n, i=1;
            while((n=inputStream.read(array))!=-1){
                res = recogniseSub(Arrays.copyOfRange(array,0,n),CONTENT_TYPE , sessionid, i++, false,isChinese);

                JSONObject js = JSONObject.fromObject(res);

                if(js.get("rawText")!=null && StringUtils.isNotBlank(js.get("rawText").toString())) {
                        System.out.println(js.get("rawType") + "        " + js.get("rawText"));
                }
            }

            res = recogniseSub(new byte[0],CONTENT_TYPE , sessionid, i, true,isChinese);
            JSONObject js = JSONObject.fromObject(res);
//			 System.out.println(js);
			System.out.println(js.get("rawType") + "        " + js.get("rawText"));
            inputStream.close();
        }catch (Exception e) {
            e.printStackTrace();
        }
	}


	static String url = "https://voice.lenovo.com/lasf/cloudasr";

	public static void main(String[] args) throws IOException {
		JavaASRHttpClient client = new JavaASRHttpClient();
		client.sendSubFile("C:\\Users\\Music\\关闭抖音.wav", true);

    }

}
