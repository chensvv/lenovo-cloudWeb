package lenovo.voice.example;

import java.security.KeyManagementException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.config.RequestConfig.Builder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
import org.apache.http.impl.nio.reactor.IOReactorConfig;

public class HttpClientFactory {

	public static CloseableHttpClient createHttpClient() throws KeyManagementException {
        Builder rcb = RequestConfig.custom();
        rcb.setSocketTimeout(30000);
        rcb.setConnectTimeout(30000);
        HttpClientBuilder hcb = HttpClientBuilder.create();
        hcb.setDefaultRequestConfig(rcb.build());
        return hcb.build();
    }
    
}