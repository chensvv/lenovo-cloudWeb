package lenovo.voice.example;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.security.KeyManagementException;
import java.util.concurrent.CountDownLatch;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.concurrent.FutureCallback;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.nio.protocol.BasicAsyncRequestProducer;
import org.apache.http.nio.protocol.BasicAsyncResponseConsumer;
import org.apache.http.nio.protocol.HttpAsyncRequestProducer;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class LasfASRService {
 
	public class Codec{
		public static final String PCM_16_16k = "audio/L16;codec=pcm;source=outer;rate=16000";
		public static final String PCM_16_8k = "audio/L16;codec=pcm;source=outer;rate=8000";
		public static final String AMR_16_16k = "audio/L16;codec=amr;source=outer;rate=16000";
		public static final String AMR_16_8k = "audio/L16;codec=amr;source=outer;rate=8000";
		public static final String MP4_16_16k = "audio/L16;codec=mp4;source=outer;rate=16000";
		public static final String MP4_16_8k = "audio/L16;codec=mp4;source=outer;rate=8000";
		public static final String MP3_16_16k = "audio/L16;codec=mp3;source=outer;rate=16000";
		public static final String MP3_16_8k = "audio/L16;codec=mp3;source=outer;rate=8000";
		public static final String AAC_16_16k = "audio/L16;codec=aac;source=outer;rate=16000";
		public static final String AAC_16_8k = "audio/L16;codec=aac;source=outer;rate=8000";
	}
	
	private String host;
	private int port;
	

	private String clientSystem;
	private String deviceType;
	private String clientVersion;
	private String deviceId;
	private int userid;
	private String developerId;
	private String appName;
	private long startTime;
	private String appkey;
	private boolean sessionMode = false;
	private String sessionDomain;
	private String resultValueLimit = "";
	private String scenario = "cmd";
	private String netType = "wifi";
	private String audioEncode = "speex-wb;7";
	private String audioFormat;
	private long sessionId;
	private int packageId;
	private int lastPackage;
	
	private byte[] voiceData;
	
	public LasfASRService(String host, int port, int userid,
			              String deviceId,String appkey,String developerId,
			              String deviceType,String appName){		
		this(host,port,userid,deviceId,appkey,
				       developerId,deviceType,appName,
				       System.getProperty("os.name")==null?"":System.getProperty("os.name").replace(" ", ""),
				       System.getProperty("os.version"));
	}
	
	public LasfASRService(String host, int port, int userid,
            String deviceId,String appkey,String developerId,
            String deviceType,String appName, String clientSystem, String clientVersion){
		this.host = host;
		this.port = port;
		this.userid = userid;
		this.deviceId = deviceId;
		this.appkey = appkey;
		this.developerId = developerId;
		this.deviceType = deviceType;
		this.appName = appName;
		this.clientSystem = clientSystem;
		this.clientVersion = clientVersion;
	}
	
	
	public String start(String sessionDomain,String audioFormat, String path){
		
		byte[] voice = getFileContent(path);
		
		return start(sessionDomain, audioFormat, voice, 1, 1);
	}
	
	public String start(String sessionDomain, byte[] voice){		
		return start(sessionDomain, Codec.PCM_16_16k, voice, 1, 1);
	}
	
	public String start(String sessionDomain,String audioFormat, byte[] voice){		
		return start(sessionDomain, audioFormat, voice, 1, 1);
	}
	
	public String start(String sessionDomain,String audioFormat, byte[] voice, int packageId, int lastPackage){
		this.startTime = System.currentTimeMillis();
		this.sessionDomain = sessionDomain;
		this.audioFormat = audioFormat;
		this.sessionId = System.currentTimeMillis();
		this.packageId = packageId;
		this.lastPackage = lastPackage;
		this.voiceData = voice;
		
		return send();
	}

	public static void main(String[] args){
		LasfASRService service = new LasfASRService("10.100.216.85", 8080, 526, "90:a4:de:ba:41:a5", 
													"0ekT/KgQg8uel9nIkTyi1BuBfTU59TKTvAuENpLV5JiK5zTMirmS8ZG7hDaS1eSYiu", 
													"com.lenovo.rt.urc", "lenovo", "Lenobot1.0");
		String data = service.start("all", Codec.PCM_16_16k,"10000.wav");
		System.out.println(data);
	}
	
	
	private byte[] getFileContent(String path){
		byte[] data = null;
		
		try {
			logPrint(path);
			FileInputStream inputStream = new FileInputStream(path);
			ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
			int i = -1;
			while((i = inputStream.read())!=-1){
				outputStream.write(i);
			}
			data = outputStream.toByteArray();
			outputStream.flush();
			outputStream.close();
			inputStream.close();
			
		} catch (FileNotFoundException e) {
			logPrint(e.getMessage());
		} catch (IOException e) {
			logPrint(e.getMessage());
		}
		
		return data;
	}
	
	
	
	

	private void setHeaders(HttpPost httpPost){
		httpPost.setHeader("User-Agent", "{platform=[\""+clientSystem+"\"], name=[\""+appName+"\"], version=[\""+clientVersion+"\"]}");
	}
	
	private String settingParams(){
		StringBuffer sb = new StringBuffer();
		sb.append("&cpf=").append(clientSystem)
		  .append("&dtp=").append(deviceType)
		  .append("&ver=").append(clientVersion)
		  .append("&did=").append(deviceId)
		  .append("&uid=").append(userid)
		  .append("&dev=").append(developerId)
		  .append("&app=").append(appName)
		  .append("&stm=").append(startTime)
		  .append("&key=").append(appkey)
		  .append("&ssm=").append(sessionMode)
		  .append("&vdm=").append(sessionDomain)
		  .append("&rvr=").append(resultValueLimit)
		  .append("&sce=").append(scenario)
		  .append("&ntt=").append(netType)
		  .append("&aue=").append(audioEncode)
		  .append("&auf=").append(URLEncoder.encode(audioFormat))
		  .append("&ixid=").append(sessionId)
		  .append("&pidx=").append(packageId)
		  .append("&over=").append(lastPackage==1?1:0);
		String data = sb.toString().substring(1);
		return data;
	}
	
	String successResponseHandler(HttpEntity entity){
		String data = null;
		try {
			String _entity = EntityUtils.toString(entity);
			logPrint(_entity);
			JSONObject jsonObject = new JSONObject(_entity);
			if(jsonObject.get("nText") != null){
				JSONArray jArray = (JSONArray) jsonObject.get("nText");
				data = jArray.get(0).toString();
			}
		} catch (JSONException e) {
			logPrint(e.getMessage());
		} catch (ParseException e) {
			logPrint(e.getMessage());
		} catch (IOException e) {
			logPrint(e.getMessage());
		}
		
		logPrint(data);
		return data;
	}
	
	public String send(){
		String result_data = "";
		if(voiceData == null) return result_data;
		
		
		try {
			
			CloseableHttpClient httpAsyncClient = HttpClientFactory.createHttpClient();
			URI _uri = new URI("http", null, host, port, "/lasf/asr", null, null);
			
			HttpPost httpPost = new HttpPost(_uri);
			setHeaders(httpPost);
			
			MultipartEntityBuilder me = MultipartEntityBuilder.create();
			me.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);
			me.addTextBody("param-data", settingParams(), ContentType.create("text/plain", Charset.forName("UTF-8")));
			me.addBinaryBody("voice-data",voiceData,ContentType.create("application/octet-stream"),"");
			httpPost.setEntity(me.build());
			
			HttpResponse response = httpAsyncClient.execute(httpPost);
			result_data = successResponseHandler(response.getEntity());
			httpAsyncClient.close();
			
		} catch (KeyManagementException e) {
			logPrint(e.getMessage());
		} catch (URISyntaxException e) {
			logPrint(e.getMessage());
		} catch (IOException e) {
			logPrint(e.getMessage());
		}
		logPrint(result_data);
		return result_data;
	}
	
	void logPrint(String data){
		System.out.println(data);
	}
	
}
